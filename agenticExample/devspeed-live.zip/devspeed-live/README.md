# DevSpeed Live — Integraciones de Software Rápidas con Agentes IA

Patrón **Coordinador/Despachador + Pipeline Secuencial** con Google ADK, Gemini (API key de AI Studio)
y tres microservicios expuestos como servidores **MCP**.

```
Usuario ─► coordinator (sin herramientas, solo enruta)
             ├─► order_workflow (SequentialAgent)
             │     1. inventory_agent ──MCP──► inventory :8001
             │     2. order_agent     ──MCP──► orders    :8002   (solo si hubo reserva)
             └─► delivery_agent       ──MCP──► delivery  :8003
```

## Arranque rápido

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp agents/devspeed_integrador/.env.example agents/devspeed_integrador/.env   # pon tu GOOGLE_API_KEY

bash scripts/run_services.sh      # terminal 1: servidores MCP
python scripts/smoke_test.py      # terminal 2: verificación sin LLM
bash scripts/run_agents.sh        # terminal 2: UI en http://localhost:8000
python scripts/demo_cli.py        # alternativa sin UI
```

## Estructura

| Archivo | Rol arquitectónico |
| --- | --- |
| `services/*_server.py` | Fachadas MCP de los microservicios (Adapter) |
| `agents/devspeed_integrador/toolsets.py` | Conexión MCP + mínimo privilegio (`tool_filter`) |
| `agents/devspeed_integrador/guardrails.py` | Reglas deterministas (callbacks de ADK) |
| `agents/devspeed_integrador/agent.py` | Roles Gaia → agentes; `root_agent` |
| `scripts/` | Arranque, prueba de humo y demo programática |

Probado con `google-adk` 2.11 y `mcp` 2.2 (Python 3.13). Con `mcp` 1.x cambia el import:
`from mcp.server.fastmcp import FastMCP as MCPServer` y `host`/`port` van en el constructor.
