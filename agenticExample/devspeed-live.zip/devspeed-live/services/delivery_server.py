"""
Servicio de Despachos expuesto como servidor MCP (Streamable HTTP).

Puerto por defecto: 8003  ->  http://127.0.0.1:8003/mcp
"""
import os
import uuid

from mcp.server.mcpserver import MCPServer

mcp = MCPServer(
    name="delivery-service",
    instructions="Servicio de despachos: agendar y consultar entregas de paquetes.",
)

_DELIVERIES: dict[str, dict] = {}


@mcp.tool()
def schedule_delivery(customer_id: str, provider_id: str, package_id: str, delivery_time: str) -> dict:
    """Agenda la entrega de un paquete. delivery_time en formato ISO 8601 (YYYY-MM-DD HH:MM:SS)."""
    if package_id in _DELIVERIES:
        return {"status": "duplicate", "package_id": package_id}
    delivery = {
        "delivery_id": f"dlv-{uuid.uuid4().hex[:8]}",
        "customer_id": customer_id,
        "provider_id": provider_id,
        "package_id": package_id,
        "delivery_time": delivery_time,
        "state": "scheduled",
    }
    _DELIVERIES[package_id] = delivery
    return {"status": "scheduled", "delivery": delivery}


@mcp.tool()
def get_delivery(package_id: str) -> dict:
    """Consulta el estado de la entrega de un paquete."""
    d = _DELIVERIES.get(package_id)
    return {"status": "ok", "delivery": d} if d else {"status": "not_found", "package_id": package_id}


@mcp.tool()
def cancel_all_deliveries() -> dict:
    """[ADMIN] Cancela TODAS las entregas. Herramienta peligrosa: no debe exponerse al agente."""
    n = len(_DELIVERIES)
    _DELIVERIES.clear()
    return {"status": "cancelled", "count": n}


if __name__ == "__main__":
    mcp.run(
        transport="streamable-http",
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "8003")),
    )
