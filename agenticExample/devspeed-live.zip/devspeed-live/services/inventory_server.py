"""
Servicio de Inventario expuesto como servidor MCP (Streamable HTTP).

Architectural concern: este proceso representa un microservicio "legado"
(sistema de registro del stock). El agente NUNCA toca la base de datos:
solo ve las herramientas que este servidor publica vía MCP.

Puerto por defecto: 8001  ->  http://127.0.0.1:8001/mcp
"""
import os
import threading

from mcp.server.mcpserver import MCPServer

mcp = MCPServer(
    name="inventory-service",
    instructions="Servicio de inventario: consulta y reserva de stock por tipo de producto.",
)

# --- "Base de datos" en memoria (en producción: Postgres, ERP, SAP, etc.) ---
_STOCK: dict[str, int] = {"Laptop": 500, "Phone": 1000}
_LOCK = threading.Lock()


@mcp.tool()
def get_stock(product_type: str) -> dict:
    """Devuelve el stock disponible de un tipo de producto (p.ej. 'Laptop', 'Phone')."""
    if product_type not in _STOCK:
        return {"status": "not_found", "product_type": product_type,
                "known_products": sorted(_STOCK)}
    return {"status": "ok", "product_type": product_type, "available": _STOCK[product_type]}


@mcp.tool()
def reserve_stock(product_type: str, quantity: int) -> dict:
    """Reserva `quantity` unidades de `product_type`. Falla si no hay stock suficiente."""
    with _LOCK:
        if product_type not in _STOCK:
            return {"status": "not_found", "product_type": product_type}
        if quantity <= 0:
            return {"status": "rejected", "reason": "quantity debe ser > 0"}
        if _STOCK[product_type] < quantity:
            return {"status": "insufficient_stock", "product_type": product_type,
                    "requested": quantity, "available": _STOCK[product_type]}
        _STOCK[product_type] -= quantity
        return {"status": "reserved", "product_type": product_type,
                "quantity": quantity, "remaining": _STOCK[product_type]}


if __name__ == "__main__":
    mcp.run(
        transport="streamable-http",
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "8001")),
    )
