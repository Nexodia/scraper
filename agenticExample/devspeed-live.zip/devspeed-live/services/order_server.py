"""
Servicio de Pedidos expuesto como servidor MCP (Streamable HTTP).

Puerto por defecto: 8002  ->  http://127.0.0.1:8002/mcp
"""
import os
from datetime import datetime, timezone

from mcp.server.mcpserver import MCPServer

mcp = MCPServer(
    name="order-service",
    instructions="Servicio de pedidos: registrar y consultar órdenes de compra.",
)

_ORDERS: dict[str, dict] = {}


@mcp.tool()
def create_order(order_id: str, product_type: str, quantity: int, unit_price: float) -> dict:
    """Registra una orden nueva. El order_id debe ser único."""
    if order_id in _ORDERS:
        return {"status": "duplicate", "order_id": order_id}
    order = {
        "order_id": order_id,
        "product_type": product_type,
        "quantity": quantity,
        "unit_price": unit_price,
        "total": round(quantity * unit_price, 2),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    _ORDERS[order_id] = order
    return {"status": "created", "order": order}


@mcp.tool()
def get_order(order_id: str) -> dict:
    """Consulta una orden por su id."""
    order = _ORDERS.get(order_id)
    return {"status": "ok", "order": order} if order else {"status": "not_found", "order_id": order_id}


if __name__ == "__main__":
    mcp.run(
        transport="streamable-http",
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "8002")),
    )
