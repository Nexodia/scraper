#!/usr/bin/env bash
# Levanta los 3 microservicios MCP en segundo plano. Ctrl+C los detiene a todos.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p logs

PORT=8001 python services/inventory_server.py > logs/inventory.log 2>&1 & P1=$!
PORT=8002 python services/order_server.py     > logs/order.log     2>&1 & P2=$!
PORT=8003 python services/delivery_server.py  > logs/delivery.log  2>&1 & P3=$!
trap 'kill $P1 $P2 $P3 2>/dev/null' EXIT INT TERM

echo "MCP inventory -> http://127.0.0.1:8001/mcp"
echo "MCP orders    -> http://127.0.0.1:8002/mcp"
echo "MCP delivery  -> http://127.0.0.1:8003/mcp"
echo "Logs en ./logs  (Ctrl+C para detener)"
wait
