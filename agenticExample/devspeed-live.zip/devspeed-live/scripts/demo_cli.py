"""
Ejecuta el sistema multiagente desde código (sin UI), útil para la demo en vivo,
tests de integración o para embeberlo en tu propio backend (FastAPI, worker, etc.).

Uso:
    python scripts/demo_cli.py
Requiere: servicios MCP corriendo + GOOGLE_API_KEY en agents/devspeed_integrador/.env
"""
import asyncio
import sys
from pathlib import Path

from dotenv import load_dotenv

AGENTS_DIR = Path(__file__).resolve().parents[1] / "agents"
load_dotenv(AGENTS_DIR / "devspeed_integrador" / ".env")
sys.path.insert(0, str(AGENTS_DIR))

from google.adk.runners import InMemoryRunner  # noqa: E402
from google.genai import types  # noqa: E402

from devspeed_integrador.agent import root_agent  # noqa: E402

PROMPTS = [
    "Por favor registra un pedido. order id es id3, product_type es Laptop, quantity 100 y unit_price 444.",
    "¿Puedes agendar esta entrega? customer_id 'cus112', provider_id 'pro232', package_id 'p3453', "
    "delivery_time 2026-06-29 08:15:27.243860",
    "Registra el pedido id4 de 900 Laptop a 444 cada uno.",  # sin stock suficiente -> la compuerta lo frena
]


async def main() -> None:
    runner = InMemoryRunner(agent=root_agent, app_name="devspeed")
    for prompt in PROMPTS:
        # Una sesión por solicitud: aislamiento de contexto entre tareas (context minimization).
        session = await runner.session_service.create_session(app_name="devspeed", user_id="demo")
        print(f"\n👤 {prompt}")
        msg = types.Content(role="user", parts=[types.Part(text=prompt)])
        async for event in runner.run_async(user_id="demo", session_id=session.id, new_message=msg):
            for part in (event.content.parts if event.content else []) or []:
                if part.function_call:
                    print(f"   🔧 {event.author} -> {part.function_call.name}({dict(part.function_call.args or {})})")
                elif part.text and event.author != "user":
                    print(f"   🤖 [{event.author}] {part.text.strip()}")
    await runner.close()


if __name__ == "__main__":
    asyncio.run(main())
