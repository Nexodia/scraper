"""
Prueba de humo SIN LLM (no gasta cuota de Gemini):
  1) se conecta a cada servidor MCP y lista sus herramientas,
  2) ejecuta una llamada real a cada uno,
  3) verifica que los guardrails bloquean argumentos maliciosos.

Requiere los servicios corriendo (scripts/run_services.sh).
"""
import asyncio
import json
import sys
from pathlib import Path

from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "agents"))
from devspeed_integrador.guardrails import validate_tool_args  # noqa: E402

SERVICES = {
    "inventory": ("http://127.0.0.1:8001/mcp", "get_stock", {"product_type": "Laptop"}),
    "orders": ("http://127.0.0.1:8002/mcp", "get_order", {"order_id": "id-404"}),
    "delivery": ("http://127.0.0.1:8003/mcp", "get_delivery", {"package_id": "p0"}),
}


async def probe(name: str, url: str, tool: str, args: dict) -> None:
    async with streamable_http_client(url) as (read, write, *_):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = [t.name for t in (await session.list_tools()).tools]
            result = await session.call_tool(tool, args)
            text = result.content[0].text if result.content else str(result.structured_content)
            print(f"[{name}] tools={tools}\n    {tool}({args}) -> {json.loads(text)}")


class _FakeTool:
    name = "create_order"


def check_guardrails() -> None:
    cases = [
        {"order_id": "id1; DROP TABLE orders", "product_type": "Laptop", "quantity": 1, "unit_price": 1},
        {"order_id": "id1", "product_type": "Laptop", "quantity": 999999, "unit_price": 1},
        {"order_id": "id1", "product_type": "Plutonio", "quantity": 1, "unit_price": 1},
        {"order_id": "id1", "product_type": "Laptop", "quantity": 10, "unit_price": 444},
    ]
    print("\n[guardrails]")
    for c in cases:
        verdict = validate_tool_args(_FakeTool(), c, None) or {"status": "allowed"}
        print(f"    {c} -> {verdict}")


async def main() -> None:
    for name, (url, tool, args) in SERVICES.items():
        await probe(name, url, tool, args)
    check_guardrails()


if __name__ == "__main__":
    asyncio.run(main())
