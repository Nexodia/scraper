#!/usr/bin/env bash
# Abre la UI de desarrollo de ADK en http://localhost:8000 (elige "devspeed_integrador").
set -euo pipefail
cd "$(dirname "$0")/../agents"
adk web --port 8000
