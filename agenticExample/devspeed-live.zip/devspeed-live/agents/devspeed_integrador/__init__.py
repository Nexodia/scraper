from . import agent  # noqa: F401  (ADK busca `agent.root_agent`)
