"""
Capa de integración: conecta los agentes con los microservicios vía MCP.

Architectural concerns que se resuelven aquí:
  * Desacoplamiento  -> los agentes conocen URLs MCP, no esquemas de BD ni SDKs.
  * Mínimo privilegio -> cada agente recibe SOLO las herramientas de su rol (tool_filter).
  * Configurabilidad -> URLs por variables de entorno (local, Docker, Cloud Run...).
"""
import os

from google.adk.tools.mcp_tool import McpToolset
from google.adk.tools.mcp_tool.mcp_session_manager import StreamableHTTPConnectionParams

INVENTORY_MCP_URL = os.getenv("INVENTORY_MCP_URL", "http://127.0.0.1:8001/mcp")
ORDER_MCP_URL = os.getenv("ORDER_MCP_URL", "http://127.0.0.1:8002/mcp")
DELIVERY_MCP_URL = os.getenv("DELIVERY_MCP_URL", "http://127.0.0.1:8003/mcp")


def _toolset(url: str, allowed: list[str]) -> McpToolset:
    return McpToolset(
        connection_params=StreamableHTTPConnectionParams(url=url, timeout=10),
        tool_filter=allowed,  # allow-list explícita: lo que no está aquí, el LLM no lo ve
    )


def inventory_tools() -> McpToolset:
    return _toolset(INVENTORY_MCP_URL, ["get_stock", "reserve_stock"])


def order_tools() -> McpToolset:
    return _toolset(ORDER_MCP_URL, ["create_order", "get_order"])


def delivery_tools() -> McpToolset:
    # Nota: el servidor también publica `cancel_all_deliveries`, pero NO se expone.
    return _toolset(DELIVERY_MCP_URL, ["schedule_delivery", "get_delivery"])
