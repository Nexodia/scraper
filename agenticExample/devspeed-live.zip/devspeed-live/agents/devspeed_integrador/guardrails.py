"""
Guardrails deterministas alrededor del LLM (callbacks de ADK).

Idea central (Parte 3 del tutorial, Beurer-Kellner et al. 2025):
"pon la seguridad ALREDEDOR del modelo, no DENTRO del prompt".
El LLM propone; el código valida y decide.

  * validate_tool_args   (before_tool_callback): valida argumentos antes de llamar al microservicio.
  * capture_reservation  (after_tool_callback):  guarda el resultado de inventario en el estado
                                                  de sesión de forma estructurada (no texto libre).
  * require_reservation  (before_agent_callback): compuerta del pipeline; el OrderAgent
                                                  no corre si no hubo reserva confirmada.
"""
import json
import re
from datetime import datetime
from typing import Any, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.genai import types

ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")
MAX_QTY = 1_000
ALLOWED_PRODUCTS = {"Laptop", "Phone"}


def _reject(reason: str) -> dict:
    # Devolver un dict desde before_tool_callback CORTA la llamada: el microservicio no se toca.
    return {"status": "blocked_by_guardrail", "reason": reason}


def validate_tool_args(tool: BaseTool, args: dict[str, Any], tool_context: ToolContext) -> Optional[dict]:
    for key in ("order_id", "customer_id", "provider_id", "package_id"):
        if key in args and not ID_RE.match(str(args[key])):
            return _reject(f"{key} con formato inválido: {args[key]!r}")

    if "product_type" in args and args["product_type"] not in ALLOWED_PRODUCTS:
        return _reject(f"product_type no permitido: {args['product_type']!r}")

    if "quantity" in args:
        try:
            q = int(args["quantity"])
        except (TypeError, ValueError):
            return _reject("quantity no es entero")
        if not 0 < q <= MAX_QTY:
            return _reject(f"quantity fuera de rango (1..{MAX_QTY})")

    if "unit_price" in args:
        try:
            if float(args["unit_price"]) <= 0:
                return _reject("unit_price debe ser > 0")
        except (TypeError, ValueError):
            return _reject("unit_price no es numérico")

    if "delivery_time" in args:
        try:
            datetime.fromisoformat(str(args["delivery_time"]))
        except ValueError:
            return _reject("delivery_time no es ISO 8601")

    return None  # None = seguir con la llamada real


def _payload(tool_response: Any) -> dict:
    """Extrae el JSON de una respuesta MCP (structuredContent o primer bloque de texto)."""
    if isinstance(tool_response, dict):
        if isinstance(tool_response.get("structuredContent"), dict):
            sc = tool_response["structuredContent"]
            return sc.get("result", sc) if isinstance(sc.get("result"), dict) else sc
        for block in tool_response.get("content") or []:
            text = block.get("text") if isinstance(block, dict) else None
            if text:
                try:
                    return json.loads(text)
                except json.JSONDecodeError:
                    pass
        return tool_response
    return {}


def capture_reservation(tool: BaseTool, args: dict[str, Any], tool_context: ToolContext,
                        tool_response: Any) -> Optional[dict]:
    if tool.name == "reserve_stock":
        data = _payload(tool_response)
        tool_context.state["reservation"] = {
            "status": data.get("status"),
            "product_type": args.get("product_type"),
            "quantity": args.get("quantity"),
        }
    return None  # no modificamos la respuesta


def require_reservation(callback_context: CallbackContext) -> Optional[types.Content]:
    res = callback_context.state.get("reservation") or {}
    if res.get("status") == "reserved":
        return None  # dejar correr al OrderAgent
    # Devolver Content SALTA al agente: decisión determinista, no del LLM.
    return types.Content(role="model", parts=[types.Part(text=(
        "Pedido NO registrado: el inventario no confirmó la reserva "
        f"(estado: {res.get('status', 'sin reserva')})."))])


def reset_reservation(callback_context: CallbackContext) -> Optional[types.Content]:
    callback_context.state["reservation"] = None
    return None
