# Preparación en Windows (PowerShell). Ejecutar desde la raíz del proyecto:
#   powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)

if (-not (Test-Path ".venv")) {
    Write-Host "Creando entorno virtual .venv ..."
    if (Get-Command py -ErrorAction SilentlyContinue) { py -3 -m venv .venv } else { python -m venv .venv }
}

.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt

$envFile = "agents\devspeed_integrador\.env"
if (-not (Test-Path $envFile)) {
    # Copy-Item conserva UTF-8. No uses "echo ... > .env": PowerShell 5 escribe UTF-16 y la key no se lee.
    Copy-Item "agents\devspeed_integrador\.env.example" $envFile
    Write-Host "Creado $envFile -> edítalo y pega tu GOOGLE_API_KEY" -ForegroundColor Yellow
}

Write-Host "`nListo. Siguientes pasos:" -ForegroundColor Green
Write-Host "  .\.venv\Scripts\Activate.ps1"
Write-Host "  python scripts\run_services.py     # terminal 1"
Write-Host "  python scripts\smoke_test.py       # terminal 2 (sin LLM)"
Write-Host "  python scripts\run_agents.py       # terminal 2 -> http://localhost:8000"
