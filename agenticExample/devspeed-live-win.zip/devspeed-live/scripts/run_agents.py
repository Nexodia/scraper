"""
Abre la UI de desarrollo de ADK en http://localhost:8000 (elige "devspeed_integrador").
Funciona igual en Windows, macOS y Linux: no depende de que `adk` esté en el PATH.

Uso:
    python scripts/run_agents.py
"""
import subprocess
import sys
from pathlib import Path

AGENTS = Path(__file__).resolve().parents[1] / "agents"

if __name__ == "__main__":
    env_file = AGENTS / "devspeed_integrador" / ".env"
    if not env_file.exists():
        sys.exit(f"Falta {env_file}. Copia .env.example como .env y pon tu GOOGLE_API_KEY.")
    try:
        subprocess.run([sys.executable, "-m", "google.adk.cli", "web", "--port", "8000"], cwd=AGENTS)
    except KeyboardInterrupt:
        pass
