# DevSpeed Live — Integraciones de Software Rápidas con Agentes IA

Patrón **Coordinador/Despachador + Pipeline Secuencial** con Google ADK, Gemini (API key de AI Studio)
y tres microservicios expuestos como servidores **MCP**. Funciona en **Windows, macOS y Linux**:
todos los lanzadores son scripts de Python.

```
Usuario ─► coordinator (sin herramientas, solo enruta)
             ├─► order_workflow (SequentialAgent)
             │     1. inventory_agent ──MCP──► inventory :8001
             │     2. order_agent     ──MCP──► orders    :8002   (solo si hubo reserva)
             └─► delivery_agent       ──MCP──► delivery  :8003
```

## Windows + VS Code (recomendado)

1. Abre la carpeta `devspeed-live` en VS Code (File > Open Folder).
2. Abre una terminal (Ctrl+ñ o Terminal > New Terminal; por defecto es PowerShell) y prepara el entorno:

   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
   ```

   Crea `.venv`, instala dependencias y copia `agents\devspeed_integrador\.env`.
3. Abre `agents\devspeed_integrador\.env` y pega tu `GOOGLE_API_KEY`.
4. Ctrl+Shift+P > **Python: Select Interpreter** > elige `.venv\Scripts\python.exe`.
5. Ejecuta, cada uno en su terminal (o con **Terminal > Run Task…**, tareas 2 a 5):

   ```powershell
   .\.venv\Scripts\Activate.ps1
   python scripts\run_services.py    # terminal 1: servidores MCP
   python scripts\smoke_test.py      # terminal 2: verificación sin LLM
   python scripts\run_agents.py      # terminal 2: UI en http://localhost:8000
   python scripts\demo_cli.py        # alternativa sin UI
   ```

6. Para depurar: pestaña **Run and Debug** (Ctrl+Shift+D) > *Todo: servicios + ADK Web*, con breakpoints
   en `guardrails.py`.

### Problemas típicos en Windows

| Síntoma | Solución |
| --- | --- |
| `Activate.ps1 cannot be loaded because running scripts is disabled` | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` (una vez) o usa las tareas de VS Code |
| `'py' / 'python' no se reconoce` | Instala Python 3.10+ de python.org marcando *Add python.exe to PATH* |
| La API key "no existe" aunque está en `.env` | El `.env` quedó en UTF-16. Créalo con `Copy-Item` o desde VS Code, nunca con `echo ... > .env` |
| `[WinError 10048]` puerto en uso | Otro proceso usa 8000–8003: `netstat -ano \| findstr :8001` y cierra ese PID |
| Firewall pregunta al iniciar los servicios | Permite solo "Redes privadas"; todo escucha en 127.0.0.1 |

## Linux / macOS

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp agents/devspeed_integrador/.env.example agents/devspeed_integrador/.env   # pon tu GOOGLE_API_KEY
python scripts/run_services.py   # terminal 1
python scripts/run_agents.py     # terminal 2
```

## Estructura

| Archivo | Rol arquitectónico |
| --- | --- |
| `services/*_server.py` | Fachadas MCP de los microservicios (Adapter) |
| `agents/devspeed_integrador/toolsets.py` | Conexión MCP + mínimo privilegio (`tool_filter`) |
| `agents/devspeed_integrador/guardrails.py` | Reglas deterministas (callbacks de ADK) |
| `agents/devspeed_integrador/agent.py` | Roles Gaia → agentes; `root_agent` |
| `scripts/` | `setup.ps1`, `run_services.py`, `run_agents.py`, `smoke_test.py`, `demo_cli.py` |
| `.vscode/` | Tareas, configuraciones de depuración e intérprete del venv |

Probado con `google-adk` 2.11 y `mcp` 2.2 (Python 3.13). Con `mcp` 1.x cambia el import:
`from mcp.server.fastmcp import FastMCP as MCPServer` y `host`/`port` van en el constructor.
